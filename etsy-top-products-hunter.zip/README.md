# Etsy Top Products Hunter (v1.0.0)

A Chrome extension (Manifest V3) that finds top-selling Etsy products by **estimated sales velocity** — ranked for **Today / Last 7 Days / Last 30 Days** — plus a **Top Stores** leaderboard and a **Shop Mode** for analyzing any single shop.

## How it works (honest data note)

Etsy does **not** publish exact per-day sales numbers publicly. This extension estimates sales velocity from public signals — the same approach used by tools like eRank and Marmalead:

1. **Review velocity (primary signal):** fetches each listing's page and counts reviews dated within the last 1 / 7 / 30 days. More recent reviews ≈ more recent sales.
2. **"Bestseller" badge:** Etsy's own per-search bestseller flag gives a ×1.5 score boost.
3. **Shop total sales ("X sales"):** used as a tiebreaker (log-scaled).
4. **Star rating + total review count:** secondary tiebreakers.

Results are estimates, not exact sales figures.

## Features

- **Search / Market / Category mode:** open any Etsy search, market or category page → click the extension → "Analyze this page".
  - Scrapes listing cards: title, URL, price + currency, shop, rating, review count, Bestseller badge, image. (Paid "Ad" cards are excluded.)
  - Detail pass: fetches up to 40 listing pages (~0.8s apart, polite) to extract review dates + shop sales.
  - 3 tabs: **Today | Last 7 Days | Last 30 Days**, ranked by estimated recent reviews.
  - **Top Stores tab (4th):** unique shops from the page, each shop's total sales fetched (up to 30 shops), ranked by total sales. Columns: rank, shop name + link, total sales, listings found on the page, shop's best listing. Click a shop row to open that shop and analyze it in Shop Mode.
- **Shop Mode:** open any `etsy.com/shop/<name>` page → "Analyze this shop".
  - Auto-scrolls to lazy-load listings (up to ~120), then ranks them by the same velocity signals. Shop name shown at the top.
  - Each listing shows an **Est. sales** figure: `round(total_reviews × 5)` for lifetime, `round(reviews_30d × 5)` / `round(reviews_7d × 5)` for recent windows. Hover "Est. sales" for the honesty note: Etsy doesn't publish exact per-listing sales — these are estimates from review counts. Raw review counts stay visible too. Shop listings rank by Est. sales (30d) descending by default.
- **CSV export** per tab (products: title, url, price, shop, shop_sales, reviews_today/7d/30d, bestseller, rating; stores: rank, shop, url, total sales, listings, best listing).
- Progress bar, listing counter, **Abort** button, polite-rate-limit note in the UI.
- 100% client-side. No external servers, no API keys. Uses your own logged-in Etsy session for page fetches.

## Install (2 minutes)

1. Open Chrome and go to `chrome://extensions`
2. Turn on **Developer mode** (toggle, top right)
3. Click **Load unpacked** and select the `etsy-hunter-extension` folder (the one containing `manifest.json`)
4. The 🎯 icon appears in your toolbar. Pin it for easy access.

## Use

1. Go to an Etsy search page (e.g. `etsy.com/search?q=candles`) or any shop page.
2. **Tip:** scroll down once so all result cards load.
3. Click the 🎯 icon → **Analyze this page** (or **Analyze this shop**).
4. Wait for the detail pass (progress bar shows status; Abort anytime).
5. Switch tabs: Today / Last 7 Days / Last 30 Days / Top Stores. Export CSV per tab.

## Good to know / limitations

- **Etsy changes its page layout regularly.** Every field uses layered fallbacks (JSON-LD structured data first, then data attributes, then URL patterns, then text heuristics), but if a future Etsy redesign breaks a selector, card counts or review dates may show as 0. Re-installing an updated version fixes it.
- Review dates come from JSON-LD `datePublished` where available, otherwise from parsed review-date text (supports "Oct 5, 2026", "5 Oct 2026", ISO dates, and relative dates like "3 days ago").
- The detail pass fetches pages with your own browser session; if Etsy ever shows a bot check, affected listings are skipped (not guessed).
- "Today" uses calendar-day precision because Etsy review dates are day-level.

## Files

- `manifest.json` — MV3 manifest
- `content.js` — page scraper (cards, review dates, shop sales, shop mode auto-scroll)
- `popup.html` / `popup.css` / `popup.js` — dashboard UI, ranking, CSV export
- `icons/` — extension icons

## Privacy

No data leaves your browser. No tracking, no accounts, no servers.
