/* Etsy Top Products Hunter — popup (VIEW ONLY)
 *
 * The long analysis runs in the page (content.js runner), NOT here:
 * Chrome destroys popups on focus loss, so popup-side loops would die.
 * Progress + results live in chrome.storage.local (eh_analysis/eh_results);
 * the popup only starts runs, shows live progress, and renders results.
 * Closing the popup never stops a run.
 */

'use strict';

const EH_ANALYSIS = 'eh_analysis';
const EH_RESULTS = 'eh_results';
const EH_ABORT = 'eh_abort';
const EH_PENDING = 'eh_pending';
const EH_KEYWORDS = 'eh_keywords';

const state = {
  mode: 'search',        // 'search' | 'shop'
  listings: [],          // scraped cards (ads filtered out)
  byId: {},              // listing_id -> listing
  details: {},           // listing_id -> detail
  order: { today: [], '7d': [], '30d': [], hot24: [] },  // tab -> [{id, vel, est?, totalReviews?}]
  stores: [],            // [{shop, shopUrl, totalSales, listingCount, bestListing}]
  activeTab: 'today',
  cartFilter: 0,          // 0 = all, or 5 / 10 / 20 (min in-carts tier)
  shopName: '',
  shopDisplayName: '',
  runId: null,
  analyzedAt: 0,
};

const $ = id => document.getElementById(id);

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function sendMsg(tabId, msg, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('content-script-timeout')), timeoutMs);
    chrome.tabs.sendMessage(tabId, msg, resp => {
      clearTimeout(timer);
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(resp);
    });
  });
}

async function ensureContentScript(tab) {
  try {
    await sendMsg(tab.id, { action: 'ping' }, 5000);
  } catch (e) {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    await sleep(800);
  }
  const ping = await sendMsg(tab.id, { action: 'ping' }, 8000);
  if (!ping || !ping.ok) throw new Error('content-script-unreachable');
  return ping;
}

/* ---------------- UI ---------------- */

function setProgress(done, total, hint) {
  $('progressWrap').classList.remove('hidden');
  const pct = total ? Math.round(done / total * 100) : 0;
  $('progressFill').style.width = pct + '%';
  $('progressText').textContent = done + ' / ' + total;
  if (hint) $('progressHint').textContent = hint;
}

function hideProgress() { $('progressWrap').classList.add('hidden'); }

function showEmpty(msg) {
  $('results').innerHTML = '<div class="empty">' + esc(msg) + '</div>';
  $('countLabel').textContent = 'No results yet';
  $('csvBtn').disabled = true;
  hideProgress();
}

function esc(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function velLabel(v) {
  return 'Est. reviews — <b>' + v.today + '</b> today · <b>' + v.d7 + '</b> / 7d · <b>' + v.d30 + '</b> / 30d';
}

function fmt(n) { return Number(n || 0).toLocaleString('en-US'); }

function cartBadge(inCarts) {
  if (inCarts == null || inCarts < 5) return '';
  const tier = inCarts >= 20 ? '20+' : inCarts >= 10 ? '10+' : '5+';
  const hot = inCarts >= 20 ? ' cart-hot' : '';
  return '<span class="badge cart-badge' + hot + '" title="Etsy shows this on the listing page">🛒 ' + tier + ' in carts</span>';
}

function currentRows() {
  const entries = (state.order && state.order[state.activeTab]) || [];
  const out = [];
  for (const e of entries) {
    const listing = state.byId[e.id];
    if (!listing) continue;
    const detail = state.details[e.id] || {};
    if (state.cartFilter && (detail.inCarts || 0) < state.cartFilter) continue;
    out.push({ listing, detail, vel: e.vel || { today: 0, d7: 0, d30: 0 }, est: e.est, totalReviews: e.totalReviews });
  }
  return out;
}

function renderListings() {
  const rows = currentRows();
  const box = $('results');
  if (!rows.length) {
    box.innerHTML = '<div class="empty">No results yet — click "Analyze".</div>';
    $('countLabel').textContent = 'No results yet';
    $('csvBtn').disabled = true;
    return;
  }
  const isHot = state.activeTab === 'hot24';
  $('countLabel').textContent = rows.length + ' products ranked' +
    (state.mode === 'shop' && !isHot ? ' by Est. sales (30d)' : isHot ? ' by views in last 24h' : '') +
    (state.cartFilter ? ' · 🛒' + state.cartFilter + '+ filter' : '');
  $('csvBtn').disabled = false;
  const isShop = state.mode === 'shop';
  box.innerHTML = rows.map((r, i) => {
    const l = r.listing;
    const salesTxt = r.detail.shop_sales != null ? ' · ' + fmt(r.detail.shop_sales) + ' shop sales' : '';
    const cb = cartBadge(r.detail.inCarts);
    let velHtml;
    if (isHot) {
      const v24 = r.detail.views24h != null ? fmt(r.detail.views24h) : '—';
      const carts = r.detail.inCarts != null ? fmt(r.detail.inCarts) : '—';
      velHtml = '<div class="vel">👁 <b>' + v24 + '</b> views in last 24h · 🛒 <b>' + carts + '</b> in carts ' +
        '<span class="est-label" title="Views are not sales — this is demand heat, not exact orders">(views ≠ sales)</span></div>';
    } else if (isShop && r.est) {
      velHtml =
        '<div class="vel"><span class="est-label" title="Estimate based on review counts (Etsy doesn\'t publish exact per-listing sales)">Est. sales</span>: ' +
          '<b>~' + fmt(r.est.total) + '</b> total · <b>~' + fmt(r.est.d30) + '</b> / 30d · <b>~' + fmt(r.est.d7) + '</b> / 7d</div>' +
        '<div class="vel raw">Reviews: <b>' + r.vel.today + '</b> today · <b>' + r.vel.d7 + '</b> / 7d · <b>' + r.vel.d30 + '</b> / 30d · <b>' + fmt(r.totalReviews) + '</b> total</div>';
    } else {
      velHtml = '<div class="vel">' + velLabel(r.vel) + '</div>';
    }
    return '<div class="row">' +
      '<div class="rank">' + (i + 1) + '</div>' +
      (l.image ? '<img class="thumb" src="' + esc(l.image) + '" alt="">' : '<div class="thumb"></div>') +
      '<div class="info">' +
        '<a class="title" href="' + esc(l.url) + '" data-url="' + esc(l.url) + '">' + esc(l.title) + '</a>' +
        '<div class="meta">' + esc(l.price || '') + (l.currency ? ' ' + esc(l.currency) : '') +
          (l.shop ? ' · ' + esc(l.shop) : '') + salesTxt +
          (l.rating ? ' · ★' + esc(l.rating) + (l.review_count ? ' (' + esc(l.review_count) + ')' : '') : '') +
          (l.bestseller ? '<span class="badge">BESTSELLER</span>' : '') + cb + '</div>' +
        velHtml +
      '</div></div>';
  }).join('');
  box.querySelectorAll('a.title').forEach(a => {
    a.addEventListener('click', ev => {
      ev.preventDefault();
      chrome.tabs.create({ url: a.getAttribute('data-url') });
    });
  });
}

function renderStores() {
  const box = $('results');
  if (!state.stores.length) {
    box.innerHTML = '<div class="empty">No store data yet — run an analysis first.</div>';
    $('countLabel').textContent = 'No store data yet';
    $('csvBtn').disabled = true;
    return;
  }
  $('countLabel').textContent = state.stores.length + ' stores ranked by total sales';
  $('csvBtn').disabled = false;
  box.innerHTML = state.stores.map((s, i) => {
    const best = s.bestListing ? '<div class="store-best">Top listing: ' + esc(s.bestListing.title) + '</div>' : '';
    return '<div class="row store-row" data-url="' + esc(s.shopUrl) + '">' +
      '<div class="rank">' + (i + 1) + '</div>' +
      '<div class="info">' +
        '<span class="store-link">' + esc(s.shop) + ' →</span>' +
        '<div class="meta">' + (s.totalSales != null ? '<b>' + Number(s.totalSales).toLocaleString() + '</b> total sales' : 'sales unknown') +
          ' · ' + s.listingCount + ' listing(s) on this page</div>' + best +
      '</div></div>';
  }).join('');
  box.querySelectorAll('.store-row').forEach(row => {
    row.addEventListener('click', async () => {
      const url = row.getAttribute('data-url');
      if (!url) return;
      // Navigate + auto-analyze the shop — works even if the popup closes.
      try { await chrome.storage.local.set({ [EH_PENDING]: { kind: 'shop', url, at: Date.now() } }); } catch (e) {}
      const tab = await getActiveTab();
      if (tab) { try { await chrome.tabs.update(tab.id, { url }); } catch (e) {} }
      setProgress(0, 1, 'Store khul raha hai — analysis khud shuru ho jayegi.');
      window.close();
    });
  });
}

function render() {
  if (state.activeTab === 'stores') renderStores();
  else renderListings();
}

let saveViewT = null;
function saveViewState() {
  // persist tab/filter choice so reopening the popup restores the same view
  clearTimeout(saveViewT);
  saveViewT = setTimeout(async () => {
    try {
      const g = await chrome.storage.local.get([EH_RESULTS]);
      const r = g && g[EH_RESULTS];
      if (r && r.runId === state.runId) {
        await chrome.storage.local.set({ [EH_RESULTS]: Object.assign({}, r, { activeTab: state.activeTab, cartFilter: state.cartFilter }) });
      }
    } catch (e) { /* ignore */ }
  }, 400);
}

function setTab(name) {
  state.activeTab = name;
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  render();
  saveViewState();
}

function setCartFilter(n) {
  state.cartFilter = n;
  document.querySelectorAll('.cfilter').forEach(b => b.classList.toggle('active', parseInt(b.dataset.cf) === n));
  render();
  saveViewState();
}

function loadResults(r) {
  if (!r || !Array.isArray(r.listings) || !r.listings.length) return false;
  state.mode = r.mode || 'search';
  state.listings = r.listings;
  state.byId = {};
  r.listings.forEach(l => { state.byId[l.listing_id] = l; });
  state.details = r.details || {};
  state.order = r.order || { today: [], '7d': [], '30d': [], hot24: [] };
  state.stores = r.stores || [];
  state.activeTab = r.activeTab || 'today';
  state.cartFilter = r.cartFilter || 0;
  state.shopName = r.shopName || '';
  state.shopDisplayName = r.shopDisplayName || '';
  state.runId = r.runId || null;
  state.analyzedAt = r.completedAt || 0;
  if (state.mode === 'shop') {
    $('shopHeader').classList.remove('hidden');
    $('shopName').textContent = state.shopDisplayName;
    const st = $('storesTab'); if (st) st.style.display = 'none';
  } else {
    $('shopHeader').classList.add('hidden');
    const st = $('storesTab'); if (st) st.style.display = '';
  }
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === state.activeTab));
  document.querySelectorAll('.cfilter').forEach(b => b.classList.toggle('active', parseInt(b.dataset.cf) === state.cartFilter));
  render();
  return true;
}

/* ---------------- CSV ---------------- */

function csvEsc(v) {
  const s = String(v == null ? '' : v);
  return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function downloadCsv(filename, rows) {
  const csv = rows.map(r => r.map(csvEsc).join(',')).join('\n');
  const blob = new Blob(["\ufeff" + csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

function exportCsv() {
  const stamp = new Date().toISOString().slice(0, 10);
  if (state.activeTab === 'stores') {
    const rows = [['rank', 'shop', 'shop_url', 'total_sales', 'listings_on_page', 'best_listing_title', 'best_listing_url']];
    state.stores.forEach((s, i) => rows.push([
      i + 1, s.shop, s.shopUrl, s.totalSales == null ? '' : s.totalSales, s.listingCount,
      s.bestListing ? s.bestListing.title : '', s.bestListing ? s.bestListing.url : ''
    ]));
    downloadCsv('etsy-top-stores-' + stamp + '.csv', rows);
    return;
  }
  const rows = [['rank', 'title', 'url', 'price', 'currency', 'shop', 'shop_sales', 'reviews_today', 'reviews_7d', 'reviews_30d', 'bestseller', 'rating', 'review_count', 'views_24h', 'in_carts']
    .concat(state.mode === 'shop' ? ['est_sales_total', 'est_sales_30d', 'est_sales_7d'] : [])];
  currentRows().forEach((r, i) => rows.push([
    i + 1, r.listing.title, r.listing.url, r.listing.price, r.listing.currency, r.listing.shop,
    r.detail.shop_sales == null ? '' : r.detail.shop_sales,
    r.vel.today, r.vel.d7, r.vel.d30,
    r.listing.bestseller ? 'yes' : 'no', r.listing.rating, r.listing.review_count,
    r.detail.views24h == null ? '' : r.detail.views24h,
    r.detail.inCarts == null ? '' : r.detail.inCarts
  ].concat(state.mode === 'shop' && r.est ? [r.est.total, r.est.d30, r.est.d7] : [])));
  const scope = state.mode === 'shop' ? 'shop-' + state.shopName + '-' : '';
  downloadCsv('etsy-top-products-' + scope + state.activeTab + '-' + stamp + '.csv', rows);
}

/* ---------------- run control (view side) ---------------- */

function onAnalysisUpdate(a) {
  if (!a) return;
  if (a.status === 'running') {
    const p = a.progress || {};
    setProgress(p.done || 0, p.total || 0,
      (p.hint || 'Chal raha hai…') + ' — popup band bhi ho jaye to rukega nahi ✓');
    $('analyzeBtn').disabled = true;
    $('abortBtn').disabled = false;
  } else if (a.status === 'done') {
    chrome.storage.local.get([EH_RESULTS]).then(g => {
      if (g && g[EH_RESULTS]) loadResults(g[EH_RESULTS]);
      setProgress(1, 1, 'Done.');
      setTimeout(hideProgress, 1500);
      $('analyzeBtn').disabled = false;
      $('abortBtn').disabled = true;
    }).catch(() => {});
  } else if (a.status === 'aborted') {
    showEmpty('Analysis rok di gayi.');
    $('analyzeBtn').disabled = false;
    $('abortBtn').disabled = true;
  } else if (a.status === 'error') {
    const friendly = {
      'no-listings-found': 'No listing cards found on this page. Scroll down to load results, then try again.',
      'content-script-timeout': 'Could not reach the page. Reload the Etsy tab and try again.',
      'content-script-unreachable': 'Could not reach the page. Reload the Etsy tab and try again.',
    }[a.error] || ('Error: ' + (a.error || 'unknown'));
    showEmpty(friendly);
    $('analyzeBtn').disabled = false;
    $('abortBtn').disabled = true;
  }
}

function storageListener(changes, area) {
  if (area !== 'local') return;
  if (changes[EH_ANALYSIS] && changes[EH_ANALYSIS].newValue) {
    onAnalysisUpdate(changes[EH_ANALYSIS].newValue);
  }
  if (changes[EH_RESULTS] && changes[EH_RESULTS].newValue) {
    const nr = changes[EH_RESULTS].newValue;
    if (nr.runId !== state.runId) loadResults(nr); // fresh completion (not our own tab/filter save)
  }
  if (changes[EH_KEYWORDS] && changes[EH_KEYWORDS].newValue) {
    const k = changes[EH_KEYWORDS].newValue;
    hideProgress();
    renderKwChips(k.keywords || [], k.seed || '');
  }
}

async function onAnalyze() {
  const tab = await getActiveTab();
  if (!tab || !tab.url || !tab.url.includes('etsy.com')) { showEmpty('Please open an Etsy page first.'); return; }
  let ping = null;
  try { ping = await ensureContentScript(tab); } catch (e) { /* fall through */ }
  if (!ping || !ping.ok) { showEmpty('Could not reach the page. Reload the Etsy tab and try again.'); return; }
  if (['search', 'market', 'category', 'shop'].indexOf(ping.pageType) === -1) {
    showEmpty('Open an Etsy search, market, category or shop page, then click Analyze.');
    return;
  }
  setProgress(0, 1, 'Analysis shuru ho rahi hai…');
  $('analyzeBtn').disabled = true;
  $('abortBtn').disabled = false;
  $('results').innerHTML = '';
  try {
    const resp = await sendMsg(tab.id, { action: 'startAnalysis' }, 15000);
    if (!resp || !resp.ok) {
      if (resp && resp.error === 'already-running') {
        const g = await chrome.storage.local.get([EH_ANALYSIS]);
        if (g && g[EH_ANALYSIS]) onAnalysisUpdate(g[EH_ANALYSIS]);
        return;
      }
      throw new Error('start-failed');
    }
    state.runId = resp.runId;
    // watchdog: if nothing starts within 25s, say so plainly
    setTimeout(async () => {
      try {
        const g2 = await chrome.storage.local.get([EH_ANALYSIS]);
        const a = g2 && g2[EH_ANALYSIS];
        if ((!a || a.runId !== state.runId || a.status !== 'running') && $('analyzeBtn').disabled) {
          $('progressHint').textContent = 'Start nahi ho saka lagta hai — page reload karke dobara Analyze dabayen.';
          $('analyzeBtn').disabled = false;
          $('abortBtn').disabled = true;
        }
      } catch (e) { /* ignore */ }
    }, 25000);
  } catch (e) {
    showEmpty('Start nahi ho saka — page reload karke dobara try karen.');
    $('analyzeBtn').disabled = false;
    $('abortBtn').disabled = true;
  }
}

async function onAbort() {
  $('progressHint').textContent = 'Aborting…';
  try {
    const g = await chrome.storage.local.get([EH_ANALYSIS]);
    const a = g && g[EH_ANALYSIS];
    await chrome.storage.local.set({ [EH_ABORT]: { runId: (a && a.runId) || state.runId, at: Date.now() } });
  } catch (e) { /* ignore */ }
}

/* ---------------- keyword / navigation flows ---------------- */
/* These navigate the tab and leave an eh_pending intent: the content
 * script on the new page auto-continues, even if the popup is closed. */

async function firePendingAndGo(kind, url, seed) {
  try {
    await chrome.storage.local.set({ [EH_PENDING]: { kind, url, seed: seed || '', at: Date.now() }, [EH_KEYWORDS]: null });
  } catch (e) { /* ignore */ }
  const tab = await getActiveTab();
  if (!tab) return;
  setProgress(0, 1, kind === 'keywords' ? 'Keyword ideas dhoond rahe hain…' : 'Page khul raha hai — analysis khud shuru ho jayegi.');
  try { await chrome.tabs.update(tab.id, { url }); } catch (e) { /* ignore */ }
  if (kind === 'keywords') {
    setTimeout(() => {
      if (!$('progressWrap').classList.contains('hidden') && $('kwChips').classList.contains('hidden')) {
        $('progressHint').textContent = 'Ideas nahi mile — dobara try karen.';
        setTimeout(hideProgress, 2500);
      }
    }, 45000);
  }
}

async function onKeywordSearch() {
  const kw = $('kwInput').value.trim();
  if (!kw) { $('kwInput').focus(); return; }
  await firePendingAndGo('kw', 'https://www.etsy.com/search?q=' + encodeURIComponent(kw), kw);
}

async function onKeywordIdeas() {
  const seed = ($('kwInput').value || '').trim();
  const url = seed ? 'https://www.etsy.com/search?q=' + encodeURIComponent(seed) : 'https://www.etsy.com/search';
  await firePendingAndGo('keywords', url, seed);
}

async function onStoreGo() {
  const name = ($('wStoreInput').value || '').trim().replace(/^@/, '').replace(/\s+/g, '');
  if (!name) { $('wStoreInput').focus(); return; }
  await firePendingAndGo('shop', 'https://www.etsy.com/shop/' + encodeURIComponent(name), '');
}

/* ---------------- newbie mode ---------------- */

const NICHES = [
  ['💍 Jewelry', 'jewelry'],
  ['🖼️ Wall Art', 'wall art'],
  ['🕯️ Candles', 'scented candles'],
  ['👕 T-Shirts', 'funny t shirts'],
  ['💒 Wedding', 'wedding gifts'],
  ['👶 Baby', 'baby shower gifts'],
  ['🐾 Pets', 'dog gifts'],
  ['🏠 Home Decor', 'home decor'],
];

function renderNiches() {
  const box = $('nicheChips');
  box.innerHTML = NICHES.map(n =>
    '<button class="chip niche" data-kw="' + esc(n[1]) + '">' + esc(n[0]) + '</button>').join('');
  box.querySelectorAll('.niche').forEach(c => {
    c.addEventListener('click', () => {
      $('kwInput').value = c.getAttribute('data-kw');
      onKeywordSearch();
    });
  });
}

function initWelcome() {
  renderNiches();
  $('wTrending').addEventListener('click', onKeywordIdeas);
  $('wIdeas').addEventListener('click', onKeywordIdeas);
  $('wStore').addEventListener('click', () => $('wStoreRow').classList.toggle('hidden'));
  $('wStoreGo').addEventListener('click', onStoreGo);
  $('wStoreInput').addEventListener('keydown', e => { if (e.key === 'Enter') onStoreGo(); });
  $('welcomeClose').addEventListener('click', async () => {
    $('welcomeBox').classList.add('hidden');
    try { await chrome.storage.local.set({ welcomed: true }); } catch (e) {}
  });
  chrome.storage.local.get(['welcomed']).then(r => {
    if (r && r.welcomed) $('welcomeBox').classList.add('hidden');
  }).catch(() => {});
}

function renderKwChips(kws, seed) {
  const box = $('kwChips');
  box.classList.remove('hidden');
  if (!kws.length) {
    box.innerHTML = '<div class="empty">Koi keyword ideas nahi mile. Koi seed word likh kar dobara try karen (e.g. "candle", "ring").</div>';
    return;
  }
  box.innerHTML = '<div class="chips-label">👇 In me se koi keyword dabayen — foran analysis shuru ho jayegi:' +
    (seed ? ' <span class="seed-note">(seed: ' + esc(seed) + ')</span>' : '') + '</div>' +
    kws.map(k => '<button class="chip" data-kw="' + esc(k) + '">' + esc(k) + '</button>').join('');
  box.querySelectorAll('.chip').forEach(c => {
    c.addEventListener('click', () => {
      $('kwInput').value = c.getAttribute('data-kw');
      onKeywordSearch();
    });
  });
}

/* ---------------- self-update ---------------- */

const UPDATE_URL = 'https://raw.githubusercontent.com/janealora902/etsy-hunter-updates/main/version.json';

function cmpVer(a, b) {
  const pa = String(a || '0').split('.').map(x => parseInt(x) || 0);
  const pb = String(b || '0').split('.').map(x => parseInt(x) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

async function onUpdateCheck() {
  const msg = $('updMsg');
  const btn = $('updCheckBtn');
  msg.classList.remove('hidden');
  msg.textContent = 'Check ho raha hai…';
  btn.disabled = true;
  try {
    const r = await fetch(UPDATE_URL + '?t=' + Date.now());
    if (!r.ok) throw new Error('http-' + r.status);
    const info = await r.json();
    const cur = chrome.runtime.getManifest().version;
    if (!info.version || !info.zip) throw new Error('bad-manifest');
    if (cmpVer(info.version, cur) > 0) {
      msg.innerHTML =
        '⬇ <b>Naya version v' + esc(info.version) + ' available hai.</b>' +
        (info.notes ? '<br><span class="upd-notes">' + esc(info.notes) + '</span>' : '') +
        '<br><button id="updDlBtn" class="primary small">⬇ Download v' + esc(info.version) + '</button>' +
        '<div class="upd-steps">Download ke baad:<br>1️⃣ Zip ko purane extension folder par <b>unzip karke replace</b> karo<br>2️⃣ Neeche <b>↻ Reload</b> button dabao — ho gaya! ✅</div>';
      $('updDlBtn').addEventListener('click', () => {
        chrome.downloads.download({ url: info.zip, saveAs: false }, () => {
          const m2 = $('updMsg');
          if (m2) m2.innerHTML += '<br>✅ Download shuru ho gayi.';
        });
      });
    } else {
      msg.textContent = '✅ Aap ke paas latest version hai (v' + cur + ').';
    }
  } catch (e) {
    msg.textContent = '⚠️ Update check nahi ho saka — internet check karo ya thori der baad try karo.';
  }
  btn.disabled = false;
}

function initUpdater() {
  try { $('verLabel').textContent = 'v' + chrome.runtime.getManifest().version; } catch (e) {}
  $('updCheckBtn').addEventListener('click', onUpdateCheck);
  const rb = $('updReloadBtn');
  if (rb) rb.addEventListener('click', () => { try { chrome.runtime.reload(); } catch (e) {} });
}

/* ---------------- init ---------------- */

async function init() {
  initWelcome();
  initUpdater();
  document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => setTab(t.dataset.tab)));
  document.querySelectorAll('.cfilter').forEach(b => b.addEventListener('click', () => setCartFilter(parseInt(b.dataset.cf))));
  document.querySelectorAll('.cfilter').forEach(b => b.classList.toggle('active', b.dataset.cf === '0'));
  $('analyzeBtn').addEventListener('click', onAnalyze);
  $('kwBtn').addEventListener('click', onKeywordSearch);
  $('kwIdeasBtn').addEventListener('click', onKeywordIdeas);
  $('kwInput').addEventListener('keydown', e => { if (e.key === 'Enter') onKeywordSearch(); });
  $('abortBtn').addEventListener('click', onAbort);
  $('csvBtn').addEventListener('click', exportCsv);
  chrome.storage.onChanged.addListener(storageListener);

  let staleWarning = false;
  try {
    const g = await chrome.storage.local.get([EH_ANALYSIS, EH_RESULTS, EH_KEYWORDS]);
    if (g[EH_RESULTS]) loadResults(g[EH_RESULTS]);
    const a = g[EH_ANALYSIS];
    if (a && a.status === 'running') {
      if (Date.now() - (a.hb || 0) > 90000) {
        staleWarning = true;
        $('pageInfo').textContent = '⚠️ Lagta hai pichli analysis ruk gayi (page band ho gaya?) — dobara Analyze dabayen.';
      } else {
        onAnalysisUpdate(a);
      }
    }
    const k = g[EH_KEYWORDS];
    if (k && k.keywords && k.keywords.length && Date.now() - k.at < 10 * 60 * 1000) {
      renderKwChips(k.keywords, k.seed || '');
    }
  } catch (e) { /* ignore */ }

  try {
    const tab = await getActiveTab();
    if (tab && tab.url && tab.url.includes('etsy.com')) {
      const ping = await ensureContentScript(tab).catch(() => null);
      if (ping && ping.ok) {
        if (staleWarning) return;
        if (ping.pageType === 'shop') {
          $('analyzeBtn').textContent = 'Analyze this shop';
          $('pageInfo').textContent = 'Shop detected: ' + (ping.shopDisplayName || ping.shopName) + ' — click to rank its listings.';
        } else if (['search', 'market', 'category'].includes(ping.pageType)) {
          $('pageInfo').textContent = 'Etsy ' + ping.pageType + ' page detected — click to find top products. Tip: scroll down first to load all results.';
        } else {
          $('pageInfo').textContent = 'Open an Etsy search, market, category or shop page for best results.';
        }
        return;
      }
    }
    if (!staleWarning) $('pageInfo').textContent = 'Open an Etsy search, market, category or shop page, then click Analyze.';
  } catch (e) {
    if (!staleWarning) $('pageInfo').textContent = 'Open an Etsy page, then click Analyze.';
  }
}

document.addEventListener('DOMContentLoaded', init);
