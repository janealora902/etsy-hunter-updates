/* Etsy Top Products Hunter — popup logic
 * Orchestrates: card scrape -> detail pass (review dates, ~800ms polite delay)
 * -> velocity ranking (Today / 7d / 30d) + Top Stores leaderboard.
 * Shop mode: auto-scroll lazy-load on etsy.com/shop/<name>, cap ~120.
 */

'use strict';

const DETAIL_DELAY_MS = 800;
const MAX_DETAIL_SEARCH = 40;   // listing pages fetched in search mode
const MAX_DETAIL_SHOP = 120;    // listing pages fetched in shop mode
const MAX_STORES = 30;          // shop pages fetched for leaderboard

const state = {
  mode: 'search',        // 'search' | 'shop'
  pageType: 'other',
  pageUrl: '',
  shopName: '',
  shopDisplayName: '',
  listings: [],          // scraped cards (ads filtered out)
  details: {},           // listing_id -> {review_dates:[], shop_sales, method} | {error}
  ranked: { today: [], '7d': [], '30d': [] },
  stores: [],            // [{shop, shopUrl, totalSales, listingCount, bestListing}]
  activeTab: 'today',
  cartFilter: 0,          // 0 = all, or 5 / 10 / 20 (min in-carts tier)
  analyzing: false,
  aborted: false,
};

const $ = id => document.getElementById(id);

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function sendMsg(tabId, msg, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('content-script-timeout')), timeoutMs);
    chrome.tabs.sendMessage(tabId, msg, resp => {
      clearTimeout(timer);
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(resp);
    });
  });
}

/* ---------------- date / velocity ---------------- */

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

function velocity(reviewDates) {
  const today0 = startOfToday();
  const d1 = new Date(today0.getTime() - 1 * 864e5);
  const d7 = new Date(today0.getTime() - 7 * 864e5);
  const d30 = new Date(today0.getTime() - 30 * 864e5);
  let t = 0, w7 = 0, w30 = 0;
  for (const ds of reviewDates) {
    const d = new Date(ds + 'T12:00:00');
    if (isNaN(d)) continue;
    if (d >= today0) { t++; w7++; w30++; }
    else if (d >= d1 && d < today0) { /* yesterday counts for 7d/30d only */ w7++; w30++; }
    else if (d >= d7) { w7++; w30++; }
    else if (d >= d30) { w30++; }
  }
  // Note: "today" uses calendar-day precision (review dates are day-level).
  return { today: t, d7: w7, d30: w30 };
}

function scoreOf(listing, detail, windowKey) {
  const v = velocity(detail.review_dates || {});
  const base = windowKey === 'today' ? v.today : windowKey === '7d' ? v.d7 : v.d30;
  return base * (listing.bestseller ? 1.5 : 1);
}

function tiebreakKey(listing, detail) {
  const sales = (detail && detail.shop_sales) || 0;
  return [
    Math.log10(sales + 1),
    parseFloat(listing.rating) || 0,
    parseInt(listing.review_count) || 0,
  ];
}

function rankListings(listings, details, windowKey) {
  const rows = listings.map(l => {
    const d = details[l.listing_id] || { review_dates: [] };
    const v = velocity(d.review_dates || []);
    return { listing: l, detail: d, vel: v, score: scoreOf(l, d, windowKey), tie: tiebreakKey(l, d) };
  });
  rows.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    for (let i = 0; i < 3; i++) if (b.tie[i] !== a.tie[i]) return b.tie[i] - a.tie[i];
    return 0;
  });
  return rows;
}

/* Hot 24h: rank by Etsy's own on-page "X views in the last 24 hours"
 * (+ "in Y carts" as tiebreak). Views ≠ sales — labeled honestly in UI. */
function rankHot24(listings, details) {
  const rows = listings.map(l => {
    const d = details[l.listing_id] || {};
    const v = velocity(d.review_dates || []);
    return { listing: l, detail: d, vel: v,
             views24h: d.views24h == null ? -1 : d.views24h,
             inCarts: d.inCarts == null ? -1 : d.inCarts };
  });
  rows.sort((a, b) => {
    if (b.views24h !== a.views24h) return b.views24h - a.views24h;
    if (b.inCarts !== a.inCarts) return b.inCarts - a.inCarts;
    return b.vel.d7 - a.vel.d7;
  });
  return rows;
}

/* Shop mode: rank by estimated sales.
 * Etsy doesn't publish exact per-listing sales, so:
 *   estimated_sales   = round(total_reviews × 5)
 *   est_sales_30d     = round(reviews_30d × 5)
 *   est_sales_7d      = round(reviews_7d × 5)
 * Default ranking: est_sales_30d descending.
 */
function rankShopListings(listings, details, windowKey) {
  const rows = listings.map(l => {
    const d = details[l.listing_id] || { review_dates: [] };
    const v = velocity(d.review_dates || []);
    const totalReviews = parseInt(l.review_count) || 0;
    const est = {
      total: Math.round(totalReviews * 5),
      d7: Math.round(v.d7 * 5),
      d30: Math.round(v.d30 * 5),
    };
    return { listing: l, detail: d, vel: v, est, totalReviews };
  });
  const key = windowKey === '7d' ? 'd7' : windowKey === '30d' ? 'd30' : 'today';
  rows.sort((a, b) => {
    const av = key === 'today' ? a.vel.today : a.est[key];
    const bv = key === 'today' ? b.vel.today : b.est[key];
    if (bv !== av) return bv - av;
    if (b.est.d30 !== a.est.d30) return b.est.d30 - a.est.d30;
    if (b.est.total !== a.est.total) return b.est.total - a.est.total;
    return (parseFloat(b.listing.rating) || 0) - (parseFloat(a.listing.rating) || 0);
  });
  return rows;
}

/* ---------------- UI ---------------- */

function setProgress(done, total, hint) {
  $('progressWrap').classList.remove('hidden');
  const pct = total ? Math.round(done / total * 100) : 0;
  $('progressFill').style.width = pct + '%';
  $('progressText').textContent = done + ' / ' + total;
  if (hint) $('progressHint').textContent = hint;
}

function hideProgress() { $('progressWrap').classList.add('hidden'); }

function esc(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function velLabel(v) {
  return 'Est. reviews — <b>' + v.today + '</b> today · <b>' + v.d7 + '</b> / 7d · <b>' + v.d30 + '</b> / 30d';
}

function fmt(n) { return Number(n || 0).toLocaleString('en-US'); }

function cartBadge(inCarts) {
  if (inCarts == null || inCarts < 5) return '';
  const tier = inCarts >= 20 ? '20+' : inCarts >= 10 ? '10+' : '5+';
  const hot = inCarts >= 20 ? ' cart-hot' : '';
  return '<span class="badge cart-badge' + hot + '" title="Etsy shows this on the listing page">🛒 ' + tier + ' in carts</span>';
}

function passesCartFilter(r) {
  if (!state.cartFilter) return true;
  const c = (r.detail && r.detail.inCarts) || 0;
  return c >= state.cartFilter;
}

function renderListings() {
  let rows = (state.ranked[state.activeTab] || []).filter(passesCartFilter);
  const box = $('results');
  if (!rows.length) {
    box.innerHTML = '<div class="empty">No results yet — click "Analyze".</div>';
    $('countLabel').textContent = 'No results yet';
    $('csvBtn').disabled = true;
    return;
  }
  const isHot = state.activeTab === 'hot24';
  $('countLabel').textContent = rows.length + ' products ranked' +
    (state.mode === 'shop' && !isHot ? ' by Est. sales (30d)' : isHot ? ' by views in last 24h' : '') +
    (state.cartFilter ? ' · 🛒' + state.cartFilter + '+ filter' : '');
  $('csvBtn').disabled = false;
  const isShop = state.mode === 'shop';
  box.innerHTML = rows.map((r, i) => {
    const l = r.listing;
    const salesTxt = r.detail.shop_sales != null ? ' · ' + fmt(r.detail.shop_sales) + ' shop sales' : '';
    const cb = cartBadge(r.detail.inCarts);
    let velHtml;
    if (isHot) {
      const v24 = r.detail.views24h != null ? fmt(r.detail.views24h) : '—';
      const carts = r.detail.inCarts != null ? fmt(r.detail.inCarts) : '—';
      velHtml = '<div class="vel">👁 <b>' + v24 + '</b> views in last 24h · 🛒 <b>' + carts + '</b> in carts ' +
        '<span class="est-label" title="Views are not sales — this is demand heat, not exact orders">(views ≠ sales)</span></div>';
    } else if (isShop && r.est) {
      velHtml =
        '<div class="vel"><span class="est-label" title="Estimate based on review counts (Etsy doesn\'t publish exact per-listing sales)">Est. sales</span>: ' +
          '<b>~' + fmt(r.est.total) + '</b> total · <b>~' + fmt(r.est.d30) + '</b> / 30d · <b>~' + fmt(r.est.d7) + '</b> / 7d</div>' +
        '<div class="vel raw">Reviews: <b>' + r.vel.today + '</b> today · <b>' + r.vel.d7 + '</b> / 7d · <b>' + r.vel.d30 + '</b> / 30d · <b>' + fmt(r.totalReviews) + '</b> total</div>';
    } else {
      velHtml = '<div class="vel">' + velLabel(r.vel) + '</div>';
    }
    return '<div class="row">' +
      '<div class="rank">' + (i + 1) + '</div>' +
      (l.image ? '<img class="thumb" src="' + esc(l.image) + '" alt="">' : '<div class="thumb"></div>') +
      '<div class="info">' +
        '<a class="title" href="' + esc(l.url) + '" data-url="' + esc(l.url) + '">' + esc(l.title) + '</a>' +
        '<div class="meta">' + esc(l.price || '') + (l.currency ? ' ' + esc(l.currency) : '') +
          (l.shop ? ' · ' + esc(l.shop) : '') + salesTxt +
          (l.rating ? ' · ★' + esc(l.rating) + (l.review_count ? ' (' + esc(l.review_count) + ')' : '') : '') +
          (l.bestseller ? '<span class="badge">BESTSELLER</span>' : '') + cb + '</div>' +
        velHtml +
      '</div></div>';
  }).join('');
  box.querySelectorAll('a.title').forEach(a => {
    a.addEventListener('click', ev => {
      ev.preventDefault();
      chrome.tabs.create({ url: a.getAttribute('data-url') });
    });
  });
}

function renderStores() {
  const box = $('results');
  if (!state.stores.length) {
    box.innerHTML = '<div class="empty">No store data yet — run an analysis first.</div>';
    $('countLabel').textContent = 'No store data yet';
    $('csvBtn').disabled = true;
    return;
  }
  $('countLabel').textContent = state.stores.length + ' stores ranked by total sales';
  $('csvBtn').disabled = false;
  box.innerHTML = state.stores.map((s, i) => {
    const best = s.bestListing ? '<div class="store-best">Top listing: ' + esc(s.bestListing.title) + '</div>' : '';
    return '<div class="row store-row" data-url="' + esc(s.shopUrl) + '">' +
      '<div class="rank">' + (i + 1) + '</div>' +
      '<div class="info">' +
        '<span class="store-link">' + esc(s.shop) + ' →</span>' +
        '<div class="meta">' + (s.totalSales != null ? '<b>' + Number(s.totalSales).toLocaleString() + '</b> total sales' : 'sales unknown') +
          ' · ' + s.listingCount + ' listing(s) on this page</div>' + best +
      '</div></div>';
  }).join('');
  box.querySelectorAll('.store-row').forEach(row => {
    row.addEventListener('click', async () => {
      const url = row.getAttribute('data-url');
      const tab = await getActiveTab();
      // Navigate current tab to the shop — user reopens popup and clicks "Analyze this shop".
      await chrome.tabs.update(tab.id, { url });
      window.close();
    });
  });
}

function render() {
  if (state.activeTab === 'stores') renderStores();
  else renderListings();
}

function setTab(name) {
  state.activeTab = name;
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  render();
  saveState();
}

function setCartFilter(n) {
  state.cartFilter = n;
  document.querySelectorAll('.cfilter').forEach(b => b.classList.toggle('active', parseInt(b.dataset.cf) === n));
  render();
  saveState();
}

/* ---------------- persistence ---------------- */
/* Chrome extension popups are DESTROYED the moment they lose focus
 * (e.g. when a listing link opens a new tab). All in-memory results
 * would be lost, so we persist the last analysis to chrome.storage.local
 * and restore it automatically when the popup reopens. */

const STORAGE_KEY = 'lastResults';

function saveState() {
  try {
    const payload = {
      mode: state.mode,
      listings: state.listings,
      details: state.details,
      ranked: state.ranked,
      stores: state.stores,
      activeTab: state.activeTab,
      cartFilter: state.cartFilter,
      shopName: state.shopName,
      shopDisplayName: state.shopDisplayName,
      savedAt: Date.now(),
    };
    chrome.storage.local.set({ [STORAGE_KEY]: payload }).catch(() => {});
  } catch (e) { /* storage unavailable/quota — non-fatal */ }
}

async function restoreState() {
  let s = null;
  try {
    const got = await chrome.storage.local.get([STORAGE_KEY]);
    s = (got && got[STORAGE_KEY]) || null;
  } catch (e) { return false; }
  if (!s || !Array.isArray(s.listings) || !s.listings.length) return false;
  state.mode = s.mode || 'search';
  state.listings = s.listings;
  state.details = s.details || {};
  state.ranked = s.ranked || { today: [], '7d': [], '30d': [], 'hot24': [] };
  state.stores = s.stores || [];
  state.cartFilter = s.cartFilter || 0;
  state.shopName = s.shopName || '';
  state.shopDisplayName = s.shopDisplayName || '';
  if (state.mode === 'shop') {
    $('shopHeader').classList.remove('hidden');
    $('shopName').textContent = state.shopDisplayName;
    const st = $('storesTab'); if (st) st.style.display = 'none';
  }
  state.activeTab = s.activeTab || 'today';
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === state.activeTab));
  document.querySelectorAll('.cfilter').forEach(b => b.classList.toggle('active', parseInt(b.dataset.cf) === state.cartFilter));
  render();
  return true;
}

/* ---------------- CSV ---------------- */

function csvEsc(v) {
  const s = String(v == null ? '' : v);
  return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function downloadCsv(filename, rows) {
  const csv = rows.map(r => r.map(csvEsc).join(',')).join('\n');
  const blob = new Blob(["\ufeff" + csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

function exportCsv() {
  const stamp = new Date().toISOString().slice(0, 10);
  if (state.activeTab === 'stores') {
    const rows = [['rank', 'shop', 'shop_url', 'total_sales', 'listings_on_page', 'best_listing_title', 'best_listing_url']];
    state.stores.forEach((s, i) => rows.push([
      i + 1, s.shop, s.shopUrl, s.totalSales == null ? '' : s.totalSales, s.listingCount,
      s.bestListing ? s.bestListing.title : '', s.bestListing ? s.bestListing.url : ''
    ]));
    downloadCsv('etsy-top-stores-' + stamp + '.csv', rows);
    return;
  }
  const rows = [['rank', 'title', 'url', 'price', 'currency', 'shop', 'shop_sales', 'reviews_today', 'reviews_7d', 'reviews_30d', 'bestseller', 'rating', 'review_count', 'views_24h', 'in_carts']
    .concat(state.mode === 'shop' ? ['est_sales_total', 'est_sales_30d', 'est_sales_7d'] : [])];
  const list = (state.ranked[state.activeTab] || []).filter(passesCartFilter);
  list.forEach((r, i) => rows.push([
    i + 1, r.listing.title, r.listing.url, r.listing.price, r.listing.currency, r.listing.shop,
    r.detail.shop_sales == null ? '' : r.detail.shop_sales,
    r.vel.today, r.vel.d7, r.vel.d30,
    r.listing.bestseller ? 'yes' : 'no', r.listing.rating, r.listing.review_count,
    r.detail.views24h == null ? '' : r.detail.views24h,
    r.detail.inCarts == null ? '' : r.detail.inCarts
  ].concat(state.mode === 'shop' && r.est ? [r.est.total, r.est.d30, r.est.d7] : [])));
  const scope = state.mode === 'shop' ? 'shop-' + state.shopName + '-' : '';
  downloadCsv('etsy-top-products-' + scope + state.activeTab + '-' + stamp + '.csv', rows);
}

/* ---------------- analysis flows ---------------- */

async function ensureContentScript(tab) {
  try {
    await sendMsg(tab.id, { action: 'ping' }, 5000);
  } catch (e) {
    // Not injected (e.g. page loaded before install) — inject now.
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    await sleep(800);
  }
  const ping = await sendMsg(tab.id, { action: 'ping' }, 8000);
  if (!ping || !ping.ok) throw new Error('content-script-unreachable');
  return ping;
}

async function detailPass(tab, listings, maxN, phaseLabel) {
  const targets = listings.filter(l => !l.is_ad).slice(0, maxN);
  let done = 0;
  for (const l of targets) {
    if (state.aborted) break;
    setProgress(done, targets.length, phaseLabel + ' — review velocity for "' + l.title.slice(0, 40) + '…"');
    try {
      const resp = await sendMsg(tab.id, { action: 'fetchDetail', url: l.url }, 45000);
      if (resp && resp.ok) state.details[l.listing_id] = resp.detail;
      else state.details[l.listing_id] = { review_dates: [], error: (resp && resp.error) || 'fetch-failed' };
    } catch (e) {
      state.details[l.listing_id] = { review_dates: [], error: String(e.message || e) };
    }
    done++;
    if (state.aborted) break;
    await sleep(DETAIL_DELAY_MS);
  }
  setProgress(done, targets.length, 'Detail pass complete.');
}

function computeRankings() {
  if (state.mode === 'shop') {
    state.ranked.today = rankShopListings(state.listings, state.details, 'today');
    state.ranked['7d'] = rankShopListings(state.listings, state.details, '7d');
    state.ranked['30d'] = rankShopListings(state.listings, state.details, '30d');
    state.ranked['hot24'] = rankHot24(state.listings, state.details);
  } else {
    state.ranked.today = rankListings(state.listings, state.details, 'today');
    state.ranked['7d'] = rankListings(state.listings, state.details, '7d');
    state.ranked['30d'] = rankListings(state.listings, state.details, '30d');
    state.ranked['hot24'] = rankHot24(state.listings, state.details);
  }
}

async function buildTopStores(tab) {
  // Unique shops from scraped (non-ad) listings
  const shopMap = new Map();
  for (const l of state.listings) {
    if (l.is_ad || !l.shop) continue;
    if (!shopMap.has(l.shop)) {
      // derive shop URL from listing page is expensive; use Etsy search-by-shop URL pattern
      shopMap.set(l.shop, { shop: l.shop, listings: [] });
    }
    shopMap.get(l.shop).listings.push(l);
  }
  const shops = Array.from(shopMap.values()).slice(0, MAX_STORES);
  // We need shop URLs — prefer the shop_url captured during the detail pass,
  // fall back to resolving it from the listing page.
  let done = 0;
  state.stores = [];
  for (const s of shops) {
    if (state.aborted) break;
    setProgress(done, shops.length, 'Top Stores — fetching sales for "' + s.shop.slice(0, 40) + '"');
    try {
      const cached = state.details[s.listings[0].listing_id] || {};
      let shopUrl = cached.shop_url || '';
      if (!shopUrl) {
        const resp = await sendMsg(tab.id, { action: 'resolveShop', listingUrl: s.listings[0].url }, 45000);
        shopUrl = resp && resp.ok ? resp.shopUrl : '';
      }
      let totalSales = null;
      if (shopUrl) {
        const sresp = await sendMsg(tab.id, { action: 'fetchShopSales', shopUrl }, 45000);
        if (sresp && sresp.ok) totalSales = sresp.info.shop_sales;
      }
      // best listing = highest 7d score among this shop's listings
      const ranked7 = state.ranked['7d'].filter(r => r.listing.shop === s.shop);
      const best = ranked7.length ? ranked7[0].listing : s.listings[0];
      state.stores.push({ shop: s.shop, shopUrl, totalSales, listingCount: s.listings.length, bestListing: best });
    } catch (e) {
      const ranked7 = state.ranked['7d'].filter(r => r.listing.shop === s.shop);
      state.stores.push({ shop: s.shop, shopUrl: '', totalSales: null, listingCount: s.listings.length, bestListing: ranked7.length ? ranked7[0].listing : s.listings[0] });
    }
    done++;
    if (state.aborted) break;
    await sleep(DETAIL_DELAY_MS);
  }
  state.stores.sort((a, b) => (b.totalSales == null ? -1 : b.totalSales) - (a.totalSales == null ? -1 : a.totalSales));
  setProgress(done, shops.length, 'Top Stores complete.');
}

async function analyzeSearch(tab) {
  state.mode = 'search';
  const scrape = await sendMsg(tab.id, { action: 'scrapeCards' }, 30000);
  if (!scrape || !scrape.ok) throw new Error('scrape-failed');
  state.listings = scrape.listings.filter(l => !l.is_ad);
  if (!state.listings.length) throw new Error('no-listings-found');
  setProgress(0, 1, 'Found ' + state.listings.length + ' listings. Starting detail pass…');

  await detailPass(tab, state.listings, MAX_DETAIL_SEARCH, 'Detail pass');
  if (state.aborted) return;
  computeRankings();
  setTab('today');

  // Top Stores leaderboard (4th tab)
  await buildTopStores(tab);
}

async function analyzeShop(tab, ping) {
  state.mode = 'shop';
  state.shopName = ping.shopName || '';
  state.shopDisplayName = ping.shopDisplayName || ping.shopName || '';
  $('shopHeader').classList.remove('hidden');
  $('shopName').textContent = state.shopDisplayName;
  $('storesTab').style.display = 'none'; // leaderboard is for search pages

  setProgress(0, 1, 'Loading all shop listings (auto-scroll)…');
  const scrape = await sendMsg(tab.id, { action: 'scrapeShop' }, 120000);
  if (!scrape || !scrape.ok) throw new Error(scrape && scrape.error === 'aborted' ? 'aborted' : 'shop-scrape-failed');
  state.listings = scrape.listings.filter(l => !l.is_ad);
  if (!state.listings.length) throw new Error('no-listings-found');

  await detailPass(tab, state.listings, MAX_DETAIL_SHOP, 'Shop detail pass');
  if (state.aborted) return;
  computeRankings();
  setTab('30d'); // shop mode default: rank by est. sales (30d) descending
}

/* ---------------- newbie mode ---------------- */

const NICHES = [
  ['💍 Jewelry', 'jewelry'],
  ['🖼️ Wall Art', 'wall art'],
  ['🕯️ Candles', 'scented candles'],
  ['👕 T-Shirts', 'funny t shirts'],
  ['💒 Wedding', 'wedding gifts'],
  ['👶 Baby', 'baby shower gifts'],
  ['🐾 Pets', 'dog gifts'],
  ['🏠 Home Decor', 'home decor'],
];

function renderNiches() {
  const box = $('nicheChips');
  box.innerHTML = NICHES.map(n =>
    '<button class="chip niche" data-kw="' + esc(n[1]) + '">' + esc(n[0]) + '</button>').join('');
  box.querySelectorAll('.niche').forEach(c => {
    c.addEventListener('click', () => {
      $('kwInput').value = c.getAttribute('data-kw');
      onKeywordSearch();
    });
  });
}

async function navigateAndAnalyze(url, settleMs = 2000) {
  const tab = await getActiveTab();
  if (!tab) return;
  await chrome.tabs.update(tab.id, { url });
  await new Promise(resolve => {
    const timeout = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(); }, 45000);
    function listener(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
  await sleep(settleMs);
  await onAnalyze();
}

async function onStoreGo() {
  const name = ($('wStoreInput').value || '').trim().replace(/^@/, '').replace(/\s+/g, '');
  if (!name) { $('wStoreInput').focus(); return; }
  if (state.analyzing) return;
  setProgress(0, 1, 'Store khol rahe hain…');
  await navigateAndAnalyze('https://www.etsy.com/shop/' + encodeURIComponent(name), 2500);
}

function initWelcome() {
  renderNiches();
  $('wTrending').addEventListener('click', onKeywordIdeas);
  $('wIdeas').addEventListener('click', onKeywordIdeas);
  $('wStore').addEventListener('click', () => $('wStoreRow').classList.toggle('hidden'));
  $('wStoreGo').addEventListener('click', onStoreGo);
  $('wStoreInput').addEventListener('keydown', e => { if (e.key === 'Enter') onStoreGo(); });
  $('welcomeClose').addEventListener('click', async () => {
    $('welcomeBox').classList.add('hidden');
    try { await chrome.storage.local.set({ welcomed: true }); } catch (e) {}
  });
  chrome.storage.local.get(['welcomed']).then(r => {
    if (r && r.welcomed) $('welcomeBox').classList.add('hidden');
  }).catch(() => {});
}

async function onKeywordIdeas() {
  if (state.analyzing) return;
  const seed = ($('kwInput').value || '').trim();
  // Go to Etsy search for the seed (or plain search page) and harvest
  // Etsy's own related/trending search terms.
  const url = seed
    ? 'https://www.etsy.com/search?q=' + encodeURIComponent(seed)
    : 'https://www.etsy.com/search';
  setProgress(0, 1, 'Keyword ideas dhoond rahe hain…');
  const tab = await getActiveTab();
  if (!tab) { hideProgress(); return; }
  await chrome.tabs.update(tab.id, { url });
  await new Promise(resolve => {
    const timeout = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(); }, 45000);
    function listener(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
  await sleep(2000);
  try {
    await ensureContentScript({ id: tab.id });
    const resp = await sendMsg(tab.id, { action: 'scrapeKeywords' }, 20000);
    hideProgress();
    const kws = (resp && resp.ok && resp.keywords) || [];
    renderKwChips(kws, seed);
  } catch (e) {
    hideProgress();
    renderKwChips([], seed);
  }
}

function renderKwChips(kws, seed) {
  const box = $('kwChips');
  box.classList.remove('hidden');
  if (!kws.length) {
    box.innerHTML = '<div class="empty">Koi keyword ideas nahi mile. Koi seed word likh kar dobara try karen (e.g. "candle", "ring").</div>';
    return;
  }
  box.innerHTML = '<div class="chips-label">👇 In me se koi keyword dabayen — foran analysis shuru ho jayegi:' +
    (seed ? ' <span class="seed-note">(seed: ' + esc(seed) + ')</span>' : '') + '</div>' +
    kws.map(k => '<button class="chip" data-kw="' + esc(k) + '">' + esc(k) + '</button>').join('');
  box.querySelectorAll('.chip').forEach(c => {
    c.addEventListener('click', () => {
      $('kwInput').value = c.getAttribute('data-kw');
      onKeywordSearch();
    });
  });
}

async function onKeywordSearch() {
  const kw = $('kwInput').value.trim();
  if (!kw) { $('kwInput').focus(); return; }
  if (state.analyzing) return;
  setProgress(0, 1, 'Opening Etsy search for "' + kw.slice(0, 40) + '"…');
  await navigateAndAnalyze('https://www.etsy.com/search?q=' + encodeURIComponent(kw), 2000);
}

async function onAnalyze() {
  if (state.analyzing) return;
  state.analyzing = true;
  state.aborted = false;
  state.listings = [];
  state.details = {};
  state.ranked = { today: [], '7d': [], '30d': [], 'hot24': [] };
  state.stores = [];
  state.cartFilter = 0;
  document.querySelectorAll('.cfilter').forEach(b => b.classList.toggle('active', b.dataset.cf === '0'));
  $('analyzeBtn').disabled = true;
  $('abortBtn').disabled = false;
  $('results').innerHTML = '';
  try {
    const tab = await getActiveTab();
    if (!tab || !tab.url || !tab.url.includes('etsy.com')) throw new Error('not-on-etsy');
    const ping = await ensureContentScript(tab);
    state.pageType = ping.pageType;
    state.pageUrl = ping.url;
    await sendMsg(tab.id, { action: 'resetAbort' });
    if (ping.pageType === 'shop') {
      await analyzeShop(tab, ping);
    } else if (['search', 'market', 'category'].includes(ping.pageType)) {
      await analyzeSearch(tab);
    } else {
      throw new Error('open-search-or-shop');
    }
    if (!state.aborted) {
      render();
      saveState(); // keep results so reopening the popup restores them
      setProgress(1, 1, 'Done.');
      setTimeout(hideProgress, 1500);
    }
  } catch (e) {
    const msg = String((e && e.message) || e);
    const friendly = {
      'not-on-etsy': 'Please open an Etsy page first.',
      'open-search-or-shop': 'Open an Etsy search, market, category or shop page, then click Analyze.',
      'no-listings-found': 'No listing cards found on this page. Scroll down to load results, then try again. (If Etsy changed its layout, card selectors may need an update.)',
      'content-script-timeout': 'Could not reach the page. Reload the Etsy tab and try again.',
      'content-script-unreachable': 'Could not reach the page. Reload the Etsy tab and try again.',
      'aborted': 'Aborted.',
    }[msg] || ('Error: ' + msg);
    $('results').innerHTML = '<div class="empty">' + esc(friendly) + '</div>';
    hideProgress();
  }
  state.analyzing = false;
  $('analyzeBtn').disabled = false;
  $('abortBtn').disabled = true;
}

async function onAbort() {
  state.aborted = true;
  try {
    const tab = await getActiveTab();
    if (tab) await sendMsg(tab.id, { action: 'abort' }, 5000).catch(() => {});
  } catch (e) { /* ignore */ }
  $('progressHint').textContent = 'Aborting…';
}

/* ---------------- self-update ---------------- */
/* Update server: public GitHub repo "etsy-hunter-updates" (version.json + zip).
 * The popup checks for a newer version and downloads the zip itself —
 * installing still needs: unzip over the old folder + Reload in chrome://extensions
 * (Chrome does not let unpacked extensions update themselves). */
const UPDATE_URL = 'https://raw.githubusercontent.com/janealora902/etsy-hunter-updates/main/version.json';

function cmpVer(a, b) {
  const pa = String(a || '0').split('.').map(x => parseInt(x) || 0);
  const pb = String(b || '0').split('.').map(x => parseInt(x) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

async function onUpdateCheck() {
  const msg = $('updMsg');
  const btn = $('updCheckBtn');
  msg.classList.remove('hidden');
  msg.textContent = 'Check ho raha hai…';
  btn.disabled = true;
  try {
    const r = await fetch(UPDATE_URL + '?t=' + Date.now());
    if (!r.ok) throw new Error('http-' + r.status);
    const info = await r.json();
    const cur = chrome.runtime.getManifest().version;
    if (!info.version || !info.zip) throw new Error('bad-manifest');
    if (cmpVer(info.version, cur) > 0) {
      msg.innerHTML =
        '⬇ <b>Naya version v' + esc(info.version) + ' available hai.</b>' +
        (info.notes ? '<br><span class="upd-notes">' + esc(info.notes) + '</span>' : '') +
        '<br><button id="updDlBtn" class="primary small">⬇ Download v' + esc(info.version) + '</button>' +
        '<div class="upd-steps">Download ke baad:<br>1️⃣ Zip ko purane extension folder par <b>unzip karke replace</b> karo<br>2️⃣ <b>chrome://extensions</b> kholo aur <b>Reload ⟳</b> dabao</div>';
      $('updDlBtn').addEventListener('click', () => {
        chrome.downloads.download({ url: info.zip, saveAs: false }, () => {
          const m2 = $('updMsg');
          if (m2) m2.innerHTML += '<br>✅ Download shuru ho gayi.';
        });
      });
    } else {
      msg.textContent = '✅ Aap ke paas latest version hai (v' + cur + ').';
    }
  } catch (e) {
    msg.textContent = '⚠️ Update check nahi ho saka — internet check karo ya thori der baad try karo.';
  }
  btn.disabled = false;
}

function initUpdater() {
  try { $('verLabel').textContent = 'v' + chrome.runtime.getManifest().version; } catch (e) {}
  $('updCheckBtn').addEventListener('click', onUpdateCheck);
}

/* ---------------- init ---------------- */

async function init() {
  initWelcome();
  initUpdater();
  document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => setTab(t.dataset.tab)));
  document.querySelectorAll('.cfilter').forEach(b => b.addEventListener('click', () => setCartFilter(parseInt(b.dataset.cf))));
  $('analyzeBtn').addEventListener('click', onAnalyze);
  $('kwBtn').addEventListener('click', onKeywordSearch);
  $('kwIdeasBtn').addEventListener('click', onKeywordIdeas);
  $('kwInput').addEventListener('keydown', e => { if (e.key === 'Enter') onKeywordSearch(); });
  $('abortBtn').addEventListener('click', onAbort);
  $('csvBtn').addEventListener('click', exportCsv);

  // Popup was destroyed (Chrome kills popups on focus loss) — bring back the last analysis.
  let restored = false;
  try { restored = await restoreState(); } catch (e) { restored = false; }

  try {
    const tab = await getActiveTab();
    if (tab && tab.url && tab.url.includes('etsy.com')) {
      const ping = await ensureContentScript(tab).catch(() => null);
      if (ping && ping.ok) {
        if (ping.pageType === 'shop') {
          $('analyzeBtn').textContent = 'Analyze this shop';
          $('pageInfo').textContent = 'Shop detected: ' + (ping.shopDisplayName || ping.shopName) + ' — click to rank its listings.';
        } else if (['search', 'market', 'category'].includes(ping.pageType)) {
          $('pageInfo').textContent = 'Etsy ' + ping.pageType + ' page detected — click to find top products. Tip: scroll down first to load all results.';
        } else {
          $('pageInfo').textContent = 'Open an Etsy search, market, category or shop page for best results.';
        }
        if (restored) $('pageInfo').textContent = '✅ Pichli analysis wapas load ho gayi.';
        return;
      }
    }
    $('pageInfo').textContent = restored ? '✅ Pichli analysis wapas load ho gayi.' : 'Open an Etsy search, market, category or shop page, then click Analyze.';
  } catch (e) {
    $('pageInfo').textContent = 'Open an Etsy page, then click Analyze.';
  }
}

document.addEventListener('DOMContentLoaded', init);
