/* Etsy Top Products Hunter — content script
 * Runs on etsy.com pages. Scrapes listing cards on the current page and,
 * on request, fetches individual listing pages (same-origin, user's own
 * session) to extract review dates + shop sales.
 *
 * SELECTOR STRATEGY (Etsy changes markup often; 403 blocked live verification,
 * so every field uses layered fallbacks, most-stable-first):
 *  1. JSON-LD (application/ld+json) on listing pages — machine-readable,
 *     survives redesigns. Used for review dates first.
 *  2. Semantic data attributes: [data-listing-id], aria-labels ("X out of 5 stars").
 *  3. Structural hooks: a[href*="/listing/"] (URL pattern never changes),
 *     .currency-value (stable for years).
 *  4. Text heuristics: "Bestseller", "N sales", month-name date regexes.
 */

(function () {
  'use strict';

  const LISTING_URL_RE = /\/listing\/(\d+)/;
  const MONTHS = '(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)';

  let abortFlag = false;

  /* ---------------- card discovery ---------------- */

  // Strategy 1: explicit data-listing-id attributes
  function cardsByDataAttr() {
    return Array.from(document.querySelectorAll('[data-listing-id]'));
  }

  // Strategy 2: anchors pointing at /listing/<id> — group nearby anchors by id
  function cardsByListingLinks() {
    const seen = new Map();
    document.querySelectorAll('a[href*="/listing/"]').forEach(a => {
      const m = a.href.match(LISTING_URL_RE);
      if (!m) return;
      const id = m[1];
      if (!seen.has(id)) {
        // climb to a reasonable card container
        let el = a;
        for (let i = 0; i < 6 && el && el !== document.body; i++) {
          el = el.parentElement;
          if (el && (el.tagName === 'LI' || (el.querySelector && el.querySelectorAll('a[href*="/listing/"]').length >= 1 && el.getBoundingClientRect().height > 120))) {
            break;
          }
        }
        seen.set(id, el || a);
      }
    });
    return Array.from(seen.values());
  }

  function findCards() {
    let cards = cardsByDataAttr();
    if (cards.length >= 5) return { cards, method: 'data-listing-id' };
    cards = cardsByListingLinks();
    return { cards, method: 'listing-links' };
  }

  /* ---------------- field extractors (per card) ---------------- */

  function firstText(el, selectors) {
    for (const sel of selectors) {
      const n = el.querySelector(sel);
      if (n && n.textContent.trim()) return n.textContent.trim();
    }
    return '';
  }

  function extractListing(card) {
    const html = card.innerHTML || '';
    const cardText = (card.innerText || '').replace(/\s+/g, ' ').trim();

    // --- listing id + url ---
    let id = card.getAttribute && card.getAttribute('data-listing-id');
    let url = '';
    const link = card.querySelector('a[href*="/listing/"]') || (card.tagName === 'A' && card.href.match(LISTING_URL_RE) ? card : null);
    if (link && link.href) {
      const m = link.href.match(LISTING_URL_RE);
      if (m) {
        id = id || m[1];
        url = 'https://www.etsy.com/listing/' + m[1];
      }
    }
    if (!id) return null;

    // --- title ---
    let title = '';
    const img = card.querySelector('img');
    if (img && img.getAttribute('alt')) title = img.getAttribute('alt').trim();
    if (!title) title = firstText(card, ['h2', 'h3', '[class*="title" i]', '[class*="name" i]']);
    if (!title && link) title = (link.getAttribute('title') || link.getAttribute('aria-label') || '').trim();
    if (!title) title = 'Listing ' + id;

    // --- price ---
    let price = firstText(card, ['.currency-value', '[data-buy-box-region] .currency-value', '[class*="price" i] .currency-value']);
    if (!price) {
      const m = cardText.match(/([$€£])\s?([\d,]+\.?\d*)/);
      if (m) price = m[1] + m[2];
    }
    let currency = '';
    const curEl = card.querySelector('.currency-symbol');
    if (curEl) currency = curEl.textContent.trim();
    if (!currency && price) {
      if (price.includes('$')) currency = 'USD';
      else if (price.includes('£')) currency = 'GBP';
      else if (price.includes('€')) currency = 'EUR';
    }

    // --- image ---
    let image = '';
    if (img) image = img.getAttribute('data-src') || img.getAttribute('src') || '';

    // --- shop name ---
    let shop = '';
    const shopLink = card.querySelector('a[href*="etsy.com/shop/"], a[href^="/shop/"]');
    if (shopLink) shop = shopLink.textContent.trim();

    // --- rating + review count ---
    let rating = '';
    let reviewCount = '';
    const starEl = card.querySelector('[aria-label*="out of 5 stars" i]');
    if (starEl) {
      const m = starEl.getAttribute('aria-label').match(/([\d.]+)\s*out of 5/i);
      if (m) rating = m[1];
    }
    if (!rating) {
      const m = cardText.match(/([\d.]+)\s*out of 5 stars/i);
      if (m) rating = m[1];
    }
    const rc = cardText.match(/\(([\d,]+)\)/);
    if (rc) reviewCount = rc[1].replace(/,/g, '');

    // --- badges ---
    const lower = cardText.toLowerCase();
    const bestseller = /\bbestseller\b/i.test(cardText);
    const isAd = /\bad\b/i.test(cardText) && /\badvertisement\b/i.test(lower + ' ' + html.slice(0, 500).toLowerCase());

    return {
      listing_id: id, url, title: title.slice(0, 200), price, currency,
      image, shop, rating, review_count: reviewCount,
      bestseller: !!bestseller, is_ad: !!isAd
    };
  }

  /* ---------------- review date parsing ---------------- */

  function parseDateText(t, now) {
    t = t.trim();
    let m;
    // "Oct 5, 2026" / "October 5 2026"
    m = t.match(new RegExp('^' + MONTHS + '\\s+(\\d{1,2}),?\\s+(\\d{4})$', 'i'));
    if (m) return new Date(parseInt(m[3], 10), monthIndex(m[1]), parseInt(m[2], 10));
    // "5 Oct 2026"
    m = t.match(new RegExp('^(\\d{1,2})\\s+' + MONTHS + '\\s+(\\d{4})$', 'i'));
    if (m) return new Date(parseInt(m[3], 10), monthIndex(m[2]), parseInt(m[1], 10));
    // ISO 2026-10-05
    m = t.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return new Date(parseInt(m[1], 10), parseInt(m[2], 10) - 1, parseInt(m[3], 10));
    // relative: "2 days ago", "yesterday", "3 hours ago", "5 weeks ago", "2 months ago"
    m = t.match(/(\d+)\s+hours?\s+ago/i);
    if (m) return new Date(now.getTime() - parseInt(m[1], 10) * 3600e3);
    if (/^yesterday$/i.test(t)) return new Date(now.getTime() - 864e5);
    m = t.match(/(\d+)\s+days?\s+ago/i);
    if (m) return new Date(now.getTime() - parseInt(m[1], 10) * 864e5);
    m = t.match(/(\d+)\s+weeks?\s+ago/i);
    if (m) return new Date(now.getTime() - parseInt(m[1], 10) * 7 * 864e5);
    if (/^last week$/i.test(t)) return new Date(now.getTime() - 7 * 864e5);
    m = t.match(/(\d+)\s+months?\s+ago/i);
    if (m) return new Date(now.getTime() - parseInt(m[1], 10) * 30 * 864e5);
    if (/^(today|just now)$/i.test(t)) return new Date(now);
    return null;
  }

  function monthIndex(name) {
    const names = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
    return names.indexOf(name.slice(0, 3).toLowerCase());
  }

  // Layer 1: JSON-LD reviews (most reliable)
  function reviewDatesFromJsonLd(doc) {
    const dates = [];
    doc.querySelectorAll('script[type="application/ld+json"]').forEach(s => {
      let data;
      try { data = JSON.parse(s.textContent); } catch (e) { return; }
      const items = Array.isArray(data) ? data : [data];
      items.forEach(item => {
        if (!item || typeof item !== 'object') return;
        const type = (item['@type'] || '').toString().toLowerCase();
        if (type.includes('product') && item.review) {
          const reviews = Array.isArray(item.review) ? item.review : [item.review];
          reviews.forEach(r => {
            if (r && r.datePublished) dates.push(String(r.datePublished));
          });
        }
      });
    });
    return dates;
  }

  // Layer 2: DOM fallback — find review blocks and date-like text inside them
  function reviewDatesFromDom(doc, now) {
    const dates = [];
    const reviewRoot = doc.querySelector('#reviews') || doc.body;
    const walker = doc.createTreeWalker(reviewRoot, NodeFilter.SHOW_TEXT);
    const dateRe = new RegExp('(' + MONTHS + '\\s+\\d{1,2},?\\s+\\d{4}|\\d{1,2}\\s+' + MONTHS + '\\s+\\d{4}|\\d{4}-\\d{2}-\\d{2})', 'i');
    const relRe = /(\d+\s+(hours?|days?|weeks?|months?)\s+ago|yesterday|last week|today|just now)/i;
    let node;
    let scanned = 0;
    while ((node = walker.nextNode()) && scanned < 4000) {
      scanned++;
      const t = node.textContent.trim();
      if (t.length > 60 || t.length < 4) continue;
      if (dateRe.test(t) || relRe.test(t)) {
        // only count it if it looks like a review attribution context
        const parent = node.parentElement;
        const ctx = parent ? (parent.parentElement ? parent.parentElement.innerText : parent.innerText) : '';
        if (/review/i.test(ctx.slice(0, 300)) || (parent && parent.closest && parent.closest('[id*="review" i], [class*="review" i]'))) {
          const d = parseDateText(t, now);
          if (d && !isNaN(d)) dates.push(d.toISOString().slice(0, 10));
        }
      }
    }
    return dates;
  }

  function shopSalesFromDom(doc) {
    const bodyText = (doc.body ? doc.body.innerText : '').replace(/\s+/g, ' ');
    // "12,345 Sales" near shop header
    const m = bodyText.match(/([\d,]+)\s+Sales/i);
    if (m) return parseInt(m[1].replace(/,/g, ''), 10);
    return null;
  }

  async function resolveShopUrl(listingUrl) {
    const res = await fetch(listingUrl, { credentials: 'same-origin', redirect: 'follow' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const html = await res.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    // Layered: explicit shop link, then meta/JSON-LD fallbacks
    const a = doc.querySelector('a[href*="etsy.com/shop/"], a[href^="/shop/"]');
    if (a) {
      const m = a.getAttribute('href').match(/\/shop\/([^/?#]+)/);
      if (m) return 'https://www.etsy.com/shop/' + m[1];
    }
    const m2 = html.match(/"shop_url"\s*:\s*"(https:[^"]*\/shop\/[^"]+)"/);
    if (m2) return m2[1].replace(/\\\//g, '/');
    throw new Error('shop-url-not-found');
  }

  /* Social-proof signals Etsy writes on the listing page itself:
   * "X views in the last 24 hours" and "In Y carts" / "Y people have this
   * in their carts". These are real on-page numbers (views ≠ sales). */
  function listingSocialProof(doc, html) {
    const text = (doc.body && doc.body.innerText) ? doc.body.innerText : html;
    let views24h = null, inCarts = null;
    let m = text.match(/([\d,]+)\s+views?\s+in\s+the\s+last\s+24\s+hours/i);
    if (m) views24h = parseInt(m[1].replace(/,/g, ''), 10);
    m = text.match(/in\s+([\d,]+)\+?\s*carts?/i) ||
        text.match(/([\d,]+)\s+people\s+have\s+this\s+in\s+their\s+carts/i);
    if (m) inCarts = parseInt(m[1].replace(/,/g, ''), 10);
    return { views24h, inCarts };
  }

  async function fetchListingDetail(url) {
    const res = await fetch(url, { credentials: 'same-origin', redirect: 'follow' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const html = await res.text();
    if (html.length < 5000 || /captcha|robot check|are you a robot/i.test(html.slice(0, 2000))) {
      throw new Error('blocked-or-captcha');
    }
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const now = new Date();
    let dates = reviewDatesFromJsonLd(doc).map(d => String(d).slice(0, 10));
    let method = 'json-ld';
    if (dates.length === 0) {
      dates = reviewDatesFromDom(doc, now);
      method = 'dom-fallback';
    }
    // normalize + dedupe
    dates = Array.from(new Set(dates.filter(d => /^\d{4}-\d{2}-\d{2}$/.test(d))));
    const shopSales = shopSalesFromDom(doc);
    // best-effort shop URL (saves a re-fetch for the Top Stores leaderboard)
    let shopUrl = null;
    const shopA = doc.querySelector('a[href*="etsy.com/shop/"], a[href^="/shop/"]');
    if (shopA) {
      const m = shopA.getAttribute('href').match(/\/shop\/([^/?#]+)/);
      if (m) shopUrl = 'https://www.etsy.com/shop/' + m[1];
    }
    return { review_dates: dates, shop_sales: shopSales, method, shop_url: shopUrl,
             ...listingSocialProof(doc, html) };
  }

  /* ============ background analysis runner ============
   * Chrome destroys the extension popup the moment it loses focus, so a
   * long analysis CANNOT live in popup.js. It runs here, in the page:
   * progress + results are mirrored to chrome.storage.local and the
   * popup is only a view. Closing the popup never stops the run. */

  const DETAIL_DELAY_MS = 800;
  const MAX_DETAIL_SEARCH = 40;
  const MAX_DETAIL_SHOP = 120;
  const MAX_STORES = 30;
  const EH_ANALYSIS = 'eh_analysis';
  const EH_RESULTS = 'eh_results';
  const EH_ABORT = 'eh_abort';
  const EH_PENDING = 'eh_pending';
  const EH_KEYWORDS = 'eh_keywords';

  async function ehGet(keys) { try { return await chrome.storage.local.get(keys); } catch (e) { return {}; } }
  async function ehSet(obj) { try { await chrome.storage.local.set(obj); } catch (e) {} }

  /* ---- velocity + ranking (pure functions) ---- */
  function startOfToday() { const d = new Date(); d.setHours(0, 0, 0, 0); return d; }

  function velocity(reviewDates) {
    const today0 = startOfToday();
    const d1 = new Date(today0.getTime() - 864e5);
    const d7 = new Date(today0.getTime() - 7 * 864e5);
    const d30 = new Date(today0.getTime() - 30 * 864e5);
    let t = 0, w7 = 0, w30 = 0;
    for (const ds of (reviewDates || [])) {
      const d = new Date(ds + 'T12:00:00');
      if (isNaN(d)) continue;
      if (d >= today0) { t++; w7++; w30++; }
      else if (d >= d1) { w7++; w30++; }
      else if (d >= d7) { w7++; w30++; }
      else if (d >= d30) { w30++; }
    }
    return { today: t, d7: w7, d30: w30 };
  }

  function scoreOf(listing, detail, windowKey) {
    const v = velocity(detail.review_dates || []);
    const base = windowKey === 'today' ? v.today : windowKey === '7d' ? v.d7 : v.d30;
    return base * (listing.bestseller ? 1.5 : 1);
  }

  function tiebreakKey(listing, detail) {
    const sales = (detail && detail.shop_sales) || 0;
    return [Math.log10(sales + 1), parseFloat(listing.rating) || 0, parseInt(listing.review_count) || 0];
  }

  function rankListings(listings, details, windowKey) {
    const rows = listings.map(l => {
      const d = details[l.listing_id] || { review_dates: [] };
      const v = velocity(d.review_dates || []);
      return { listing: l, detail: d, vel: v, score: scoreOf(l, d, windowKey), tie: tiebreakKey(l, d) };
    });
    rows.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      for (let i = 0; i < 3; i++) if (b.tie[i] !== a.tie[i]) return b.tie[i] - a.tie[i];
      return 0;
    });
    return rows;
  }

  function rankHot24(listings, details) {
    const rows = listings.map(l => {
      const d = details[l.listing_id] || {};
      const v = velocity(d.review_dates || []);
      return { listing: l, detail: d, vel: v,
               views24h: d.views24h == null ? -1 : d.views24h,
               inCarts: d.inCarts == null ? -1 : d.inCarts };
    });
    rows.sort((a, b) => {
      if (b.views24h !== a.views24h) return b.views24h - a.views24h;
      if (b.inCarts !== a.inCarts) return b.inCarts - a.inCarts;
      return b.vel.d7 - a.vel.d7;
    });
    return rows;
  }

  function rankShopListings(listings, details, windowKey) {
    const rows = listings.map(l => {
      const d = details[l.listing_id] || { review_dates: [] };
      const v = velocity(d.review_dates || []);
      const totalReviews = parseInt(l.review_count) || 0;
      const est = { total: Math.round(totalReviews * 5), d7: Math.round(v.d7 * 5), d30: Math.round(v.d30 * 5) };
      return { listing: l, detail: d, vel: v, est, totalReviews };
    });
    const key = windowKey === '7d' ? 'd7' : windowKey === '30d' ? 'd30' : 'today';
    rows.sort((a, b) => {
      const av = key === 'today' ? a.vel.today : a.est[key];
      const bv = key === 'today' ? b.vel.today : b.est[key];
      if (bv !== av) return bv - av;
      if (b.est.d30 !== a.est.d30) return b.est.d30 - a.est.d30;
      if (b.est.total !== a.est.total) return b.est.total - a.est.total;
      return (parseFloat(b.listing.rating) || 0) - (parseFloat(a.listing.rating) || 0);
    });
    return rows;
  }

  /* ---- the run ---- */
  let runnerActive = false;

  function startAnalysisRun() {
    const runId = 'r' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36);
    ehSet({ [EH_ABORT]: null });
    runAnalysis(runId); // fire and forget — progress lives in storage
    return runId;
  }

  function scrapeCurrentPage(maxCards) {
    const found = findCards();
    const seen = new Set();
    const listings = [];
    for (const card of found.cards) {
      if (listings.length >= maxCards) break;
      try {
        const l = extractListing(card);
        if (l && !seen.has(l.listing_id)) { seen.add(l.listing_id); listings.push(l); }
      } catch (e) { /* skip bad card */ }
    }
    return listings;
  }

  async function runAnalysis(runId) {
    if (runnerActive) return;
    runnerActive = true;
    const runStart = Date.now();
    const finish = () => { runnerActive = false; };
    try {
      const pt = pageType();
      const mode = pt === 'shop' ? 'shop' : 'search';
      const pageUrl = location.href;
      const shopName = mode === 'shop' ? shopNameFromUrl() : '';
      const shopDisplayName = mode === 'shop' ? shopNameFromPage() : '';
      const progress = { done: 0, total: 0, hint: 'Shuru ho raha hai…' };
      const tick = async () => {
        await ehSet({ [EH_ANALYSIS]: { status: 'running', runId, mode, pageUrl, shopName, shopDisplayName, progress: { done: progress.done, total: progress.total, hint: progress.hint }, hb: Date.now() } });
      };
      const isAborted = async () => {
        const g = await ehGet([EH_ABORT, EH_ANALYSIS]);
        const ab = g[EH_ABORT];
        if (ab && (ab.runId === runId || (ab.at && ab.at >= runStart - 5000))) return true;
        const cur = g[EH_ANALYSIS]; // a newer run took over this page
        if (cur && cur.runId !== runId && cur.status === 'running') return true;
        return false;
      };
      const abortNow = async () => {
        await ehSet({ [EH_ANALYSIS]: { status: 'aborted', runId, mode, pageUrl, hb: Date.now() } });
        await ehSet({ [EH_ABORT]: null });
        finish();
      };

      /* 1. scrape */
      progress.hint = mode === 'shop' ? 'Shop listings load ho rahi hain (auto-scroll)…' : 'Listings scrape ho rahi hain…';
      await tick();
      let listings;
      if (mode === 'shop') {
        await autoScrollForCards(120, async c => { progress.hint = 'Shop listings load ho rahi hain… (' + c + ')'; await tick(); });
        if (await isAborted()) { await abortNow(); return; }
        listings = scrapeCurrentPage(120);
      } else {
        listings = scrapeCurrentPage(200);
      }
      listings = listings.filter(l => !l.is_ad);
      if (!listings.length) {
        await ehSet({ [EH_ANALYSIS]: { status: 'error', runId, mode, pageUrl, error: 'no-listings-found', hb: Date.now() } });
        finish(); return;
      }
      progress.hint = 'Found ' + listings.length + ' listings. Detail pass shuru…';

      /* 2. detail pass */
      const maxN = mode === 'shop' ? MAX_DETAIL_SHOP : MAX_DETAIL_SEARCH;
      const targets = listings.slice(0, maxN);
      const details = {};
      progress.total = targets.length; progress.done = 0;
      for (let i = 0; i < targets.length; i++) {
        if (await isAborted()) { await abortNow(); return; }
        const l = targets[i];
        progress.done = i;
        progress.hint = 'Detail pass — "' + l.title.slice(0, 40) + '…"';
        await tick();
        try { details[l.listing_id] = await fetchListingDetail(l.url); }
        catch (e) { details[l.listing_id] = { review_dates: [], error: String((e && e.message) || e) }; }
        progress.done = i + 1;
        await sleep(DETAIL_DELAY_MS);
      }

      /* 3. rankings */
      progress.hint = 'Ranking…'; await tick();
      const order = {};
      if (mode === 'shop') {
        order.today = rankShopListings(listings, details, 'today').map(r => ({ id: r.listing.listing_id, vel: r.vel, est: r.est, totalReviews: r.totalReviews }));
        order['7d'] = rankShopListings(listings, details, '7d').map(r => ({ id: r.listing.listing_id, vel: r.vel, est: r.est, totalReviews: r.totalReviews }));
        order['30d'] = rankShopListings(listings, details, '30d').map(r => ({ id: r.listing.listing_id, vel: r.vel, est: r.est, totalReviews: r.totalReviews }));
      } else {
        order.today = rankListings(listings, details, 'today').map(r => ({ id: r.listing.listing_id, vel: r.vel }));
        order['7d'] = rankListings(listings, details, '7d').map(r => ({ id: r.listing.listing_id, vel: r.vel }));
        order['30d'] = rankListings(listings, details, '30d').map(r => ({ id: r.listing.listing_id, vel: r.vel }));
      }
      order.hot24 = rankHot24(listings, details).map(r => ({ id: r.listing.listing_id, vel: r.vel }));

      /* 4. top stores (search mode) */
      let stores = [];
      if (mode === 'search') {
        const shopMap = new Map();
        for (const l of listings) {
          if (!l.shop) continue;
          if (!shopMap.has(l.shop)) shopMap.set(l.shop, []);
          shopMap.get(l.shop).push(l);
        }
        const shops = Array.from(shopMap.entries()).slice(0, MAX_STORES);
        const ranked7 = rankListings(listings, details, '7d');
        progress.total = shops.length; progress.done = 0;
        let si = 0;
        for (const entry of shops) {
          const sName = entry[0], sListings = entry[1];
          if (await isAborted()) { await abortNow(); return; }
          progress.hint = 'Top Stores — "' + sName.slice(0, 40) + '"';
          progress.done = si; await tick();
          try {
            const cached = details[sListings[0].listing_id] || {};
            let shopUrl = cached.shop_url || '';
            if (!shopUrl) shopUrl = await resolveShopUrl(sListings[0].url);
            let totalSales = null;
            if (shopUrl) { const info = await fetchShopSales(shopUrl); totalSales = info.shop_sales; }
            const hit = ranked7.find(r => r.listing.shop === sName);
            const best = hit ? hit.listing : sListings[0];
            stores.push({ shop: sName, shopUrl, totalSales, listingCount: sListings.length, bestListing: best });
          } catch (e) {
            const hit = ranked7.find(r => r.listing.shop === sName);
            const best = hit ? hit.listing : sListings[0];
            stores.push({ shop: sName, shopUrl: '', totalSales: null, listingCount: sListings.length, bestListing: best });
          }
          si++; progress.done = si;
          await sleep(DETAIL_DELAY_MS);
        }
        stores.sort((a, b) => (b.totalSales == null ? -1 : b.totalSales) - (a.totalSales == null ? -1 : a.totalSales));
      }

      /* 5. save + done */
      await ehSet({ [EH_RESULTS]: {
        runId, mode, pageUrl, completedAt: Date.now(),
        listings, details, order, stores,
        activeTab: mode === 'shop' ? '30d' : 'today', cartFilter: 0,
        shopName, shopDisplayName
      }});
      await ehSet({ [EH_ANALYSIS]: { status: 'done', runId, mode, pageUrl, hb: Date.now() } });
    } catch (e) {
      try { await ehSet({ [EH_ANALYSIS]: { status: 'error', runId, mode: 'search', pageUrl: location.href, error: String((e && e.message) || e), hb: Date.now() } }); } catch (e2) {}
    }
    finish();
  }

  /* auto-start after popup-triggered navigation (the popup may be closed) */
  (async function consumePending() {
    try {
      const g = await ehGet([EH_PENDING]);
      const p = g[EH_PENDING];
      if (!p || !p.url || Date.now() - p.at > 5 * 60 * 1000) return;
      const norm = u => String(u || '').replace(/\/+$/, '');
      const here = norm(location.href), want = norm(p.url);
      if (here.indexOf(want) !== 0 && want.indexOf(here) !== 0) return;
      await ehSet({ [EH_PENDING]: null });
      const pt = pageType();
      if (['search', 'market', 'category', 'shop'].indexOf(pt) === -1) return;
      await sleep(2500);
      if (p.kind === 'keywords') {
        const keywords = scrapeKeywords();
        await ehSet({ [EH_KEYWORDS]: { keywords, seed: p.seed || '', at: Date.now() } });
      } else {
        const g2 = await ehGet([EH_ANALYSIS]);
        const a = g2[EH_ANALYSIS];
        if (a && a.status === 'running' && Date.now() - (a.hb || 0) < 60000) return;
        startAnalysisRun();
      }
    } catch (e) { /* ignore */ }
  })();


  /* ---------------- message API ---------------- */

  function pageType() {
    const p = location.pathname;
    if (/^\/shop\/[^/]+\/?$/.test(p) || /^\/shop\/[^/]+\/(items|reviews|about|policies)/.test(p)) return 'shop';
    if (p.startsWith('/search')) return 'search';
    if (p.startsWith('/market/')) return 'market';
    if (/^\/c\//.test(p) || p.includes('/categories/')) return 'category';
    return 'other';
  }

  function shopNameFromUrl() {
    const m = location.pathname.match(/^\/shop\/([^/?#]+)/);
    return m ? decodeURIComponent(m[1]) : '';
  }

  function shopNameFromPage() {
    // Layered: h1 shop title, then URL fallback
    const h1 = document.querySelector('h1');
    if (h1 && h1.textContent.trim() && h1.textContent.trim().length < 80) return h1.textContent.trim();
    const meta = document.querySelector('meta[property="og:title"]');
    if (meta && meta.content) return meta.content.split('|')[0].trim();
    return shopNameFromUrl();
  }

  function countListingCards() {
    const byAttr = document.querySelectorAll('[data-listing-id]').length;
    if (byAttr >= 3) return byAttr;
    const ids = new Set();
    document.querySelectorAll('a[href*="/listing/"]').forEach(a => {
      const m = a.href.match(LISTING_URL_RE);
      if (m) ids.add(m[1]);
    });
    return ids.size;
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // Auto-scroll to trigger lazy loading on shop pages. Cap ~120 listings.
  async function autoScrollForCards(maxCards, onCount) {
    let lastCount = 0, stableRounds = 0, rounds = 0;
    while (rounds < 40 && stableRounds < 3) {
      if (abortFlag) break;
      window.scrollTo(0, document.body.scrollHeight);
      await sleep(1200);
      rounds++;
      const count = countListingCards();
      if (onCount) { try { await onCount(count); } catch (e) {} }
      if (count >= maxCards) break;
      if (count === lastCount) stableRounds++;
      else { stableRounds = 0; lastCount = count; }
    }
    window.scrollTo(0, 0);
    await sleep(400);
  }

  async function fetchShopSales(shopUrl) {
    const res = await fetch(shopUrl, { credentials: 'same-origin', redirect: 'follow' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const html = await res.text();
    if (html.length < 5000 || /captcha|are you a robot/i.test(html.slice(0, 2000))) {
      throw new Error('blocked-or-captcha');
    }
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const sales = shopSalesFromDom(doc);
    // shop display name fallback
    let name = '';
    const h1 = doc.querySelector('h1');
    if (h1 && h1.textContent.trim().length < 80) name = h1.textContent.trim();
    return { shop_sales: sales, shop_name: name };
  }

  /* Keyword Ideas: harvest related/trending search terms from the page.
   * - Search pages: Etsy's "related searches" links (a[href*="/search?q="])
   * - Homepage: trending search links
   * Returns deduped keyword list (excludes the page's own query). */
  function scrapeKeywords() {
    const found = [];
    const seen = new Set();
    const here = new URL(location.href);
    const ownQ = (here.searchParams.get('q') || '').trim().toLowerCase();
    document.querySelectorAll('a[href*="/search"]').forEach(a => {
      try {
        const u = new URL(a.href, location.origin);
        if (!u.pathname.startsWith('/search')) return;
        const q = (u.searchParams.get('q') || '').trim();
        if (!q || q.length < 2 || q.length > 60) return;
        const key = q.toLowerCase();
        if (key === ownQ || seen.has(key)) return;
        // skip nav/filter links that carry extra params like explicit sort/ref
        seen.add(key);
        found.push(q);
      } catch (e) { /* ignore */ }
    });
    // Fallback: trending module headings on homepage ("Trending", "Popular right now")
    if (!found.length) {
      document.querySelectorAll('a').forEach(a => {
        const t = (a.textContent || '').trim();
        if (t.length >= 3 && t.length <= 40 && /^[a-zA-Z0-9 &'\-]+$/.test(t) && !seen.has(t.toLowerCase())) {
          const cls = (a.className || '') + ' ' + ((a.closest('[class]') || {}).className || '');
          if (/trend|popular/i.test(cls)) { seen.add(t.toLowerCase()); found.push(t); }
        }
      });
    }
    return found.slice(0, 24);
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      try {
        if (msg.action === 'ping') {
          sendResponse({ ok: true, url: location.href, pageType: pageType(), shopName: shopNameFromUrl(), shopDisplayName: pageType() === 'shop' ? shopNameFromPage() : '' });
        } else if (msg.action === 'scrapeCards') {
          const found = findCards();
          const seen = new Set();
          const listings = [];
          for (const card of found.cards) {
            if (abortFlag) break;
            try {
              const l = extractListing(card);
              if (l && !seen.has(l.listing_id)) {
                seen.add(l.listing_id);
                listings.push(l);
              }
            } catch (e) { /* skip bad card */ }
          }
          sendResponse({ ok: true, listings, cardMethod: found.method, pageType: pageType() });
        } else if (msg.action === 'scrapeShop') {
          // Shop mode: auto-scroll to lazy-load listings (cap ~120), then scrape
          await autoScrollForCards(120);
          if (abortFlag) { sendResponse({ ok: false, error: 'aborted' }); return; }
          const found = findCards();
          const seen = new Set();
          const listings = [];
          for (const card of found.cards) {
            if (abortFlag || listings.length >= 120) break;
            try {
              const l = extractListing(card);
              if (l && !seen.has(l.listing_id)) {
                seen.add(l.listing_id);
                listings.push(l);
              }
            } catch (e) { /* skip bad card */ }
          }
          sendResponse({ ok: true, listings, cardMethod: found.method, pageType: 'shop', shopName: shopNameFromUrl(), shopDisplayName: shopNameFromPage() });
        } else if (msg.action === 'resolveShop') {
          if (abortFlag) { sendResponse({ ok: false, error: 'aborted' }); return; }
          const shopUrl = await resolveShopUrl(msg.listingUrl);
          sendResponse({ ok: true, shopUrl });
        } else if (msg.action === 'fetchShopSales') {
          if (abortFlag) { sendResponse({ ok: false, error: 'aborted' }); return; }
          const info = await fetchShopSales(msg.shopUrl);
          sendResponse({ ok: true, info });
        } else if (msg.action === 'fetchDetail') {
          if (abortFlag) { sendResponse({ ok: false, error: 'aborted' }); return; }
          const detail = await fetchListingDetail(msg.url);
          sendResponse({ ok: true, detail });
        } else if (msg.action === 'startAnalysis') {
          const gg = await chrome.storage.local.get(['eh_analysis']).catch(() => ({}));
          const aa = gg.eh_analysis;
          if (aa && aa.status === 'running' && Date.now() - (aa.hb || 0) < 60000) { sendResponse({ ok: false, error: 'already-running' }); return; }
          const runId = startAnalysisRun();
          sendResponse({ ok: true, runId });
        } else if (msg.action === 'scrapeKeywords') {
          const keywords = scrapeKeywords();
          sendResponse({ ok: true, keywords, pageType: pageType() });
        } else if (msg.action === 'abort') {
          abortFlag = true;
          sendResponse({ ok: true });
        } else if (msg.action === 'resetAbort') {
          abortFlag = false;
          sendResponse({ ok: true });
        } else {
          sendResponse({ ok: false, error: 'unknown-action' });
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e && e.message || e) });
      }
    })();
    return true; // async response
  });
})();
